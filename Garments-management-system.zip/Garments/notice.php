<?php
//if(!isset($_SESSION['username'])){
//    echo '<meta http-equiv="refresh" content="0; url=index.php" />';
//}

//include('login_required.php');

include('connection.php');
session_start();
include('session.php');

?>


<?php
    if(isset($_POST['submit'])){



       $message=$_POST['message'];
        
       $query = "INSERT INTO notice VALUES (null,'$message')";
       //echo $query;   
      $result=mysqli_query($conn,$query);
       mysqli_error($conn); 
       echo "Notice Submitted"; 

    /*    if($result){
          $query="UPDATE host_user SET status='booked' WHERE id='".$host_id."'";
        $result=mysqli_query($con,$query);
        if($result)
        {
          echo "booked";
        }
        }*/
      }
  
?>








<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
    <title>Employee Management</title>
    <link rel="stylesheet" type="text/css" href="style.css">

    <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

 
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.2/html5shiv.js"></script> -->
    

</head>
<body>





<div class="container-fluid">

    <!-- Static navbar -->
    <nav class="navbar navbar-default nav-edit">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php">Employee Report</a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav">
                    <li class="active"><a href="home.php">Home</a></li>
                    <li><a href="insert.php">Insert</a></li>
                    <li><a href="show_all.php">Show all</a></li>
                    <li><a href="notice.php">Notice</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right log-out">
                    <li><a href="log_out.php" class="log-out">LOG OUT</a></li>
                </ul>
            </div><!--/.nav-collapse -->
        </div><!--/.container-fluid -->
    </nav>

     
<div class="row">
<form action="" method="POST" class="text-center insert-form">
<div class="container">
    <div class="row text-center">
    <div class="col-md-10 col-sm-10">
        
                <p><h1>Submit Notice</h1></p>
                <input type="text" name="message" value="">
                </div>
            </div>
    </div>

     <div class="col-md-10">
                <div class="submite-button">
                    <button class="btn btn-primary btn-block" type="submit" name="submit" value="submit">Submit</button>
                </div>
            </div>

    </div>



    <div class="row">
       <!--  <table class="table home-table">
            <thead>
            <tr>
                <th  class="text-center">Name</th>
                <th  class="text-center">Email</th>
                <th  class="text-center">Mobile</th>
                <th  class="text-center">University</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td  class="text-center">Md. Fayjur Rahman (Sourov)</td>
                <td  class="text-center">sourov.gm@gmail.com</td>
                <td  class="text-center">+8801920387741</td>
                <td  class="text-center">Daffodil International University</td>
            </tr>
            </tbody>
        </table> -->
    </div>
</div>


    




</div>





<!-- Bootstrap core JavaScript
  =========================================================  -->

<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/script.js"></script>

</body>