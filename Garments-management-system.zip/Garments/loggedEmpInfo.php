<?php
function getEmpInfo(){
    $conn = mysqli_connect("localhost", "root", "","s_management");
    //echo $sql;
    $sql = "select * from `employee_info` WHERE `id`='".$_SESSION['id']."'";
    $result = mysqli_query($conn, $sql);
    $arr=array();
    while($row = mysqli_fetch_assoc($result)) {
        $arr[]=$row;
    }
    return json_encode($arr);
}

$jsonData = getEmpInfo();
$jsn=json_decode($jsonData);
echo "<pre>";print_r($jsn);echo "</pre>";

?>