<?php
session_start();
session_destroy();
unset($_SESSION['email']);
$_SESSION['massage']= "you are now logged out";
header('location:index.php');

?>