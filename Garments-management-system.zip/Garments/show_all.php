<?php
//if(!isset($_SESSION['username'])){
//    echo '<meta http-equiv="refresh" content="0; url=index.php" />';
//}

//include('login_required.php');session_start();
session_start();
include('session.php');
?>

<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
    <title>Employee Management</title>
    <link rel="stylesheet" type="text/css" href="style.css">

   

</head>
<body>

<div class="container-fluid">

    <!-- Static navbar -->
    <nav class="navbar navbar-default nav-edit">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php">Employees Info</a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="insert.php">Insert</a></li>
                    <li class="active"><a href="show_all.php">Show all</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right log-out">
                    <li><a href="log_out.php" class="log-out">LOG OUT</a></li>
                </ul>
            </div><!--/.nav-collapse -->
        </div><!--/.container-fluid -->
    </nav>





    <!-- start edit section php-->

   <?php 
    //include('../a/header.php'); 
    include('connection.php');

    if(isset($_POST['submit'])){
        $id = $_POST['id'];
        $name=$_POST['name'];
        
        $email=$_POST['email'];
        $password=$_POST['password'];
        $salary=$_POST['salary'];
        $phone=$_POST['phone'];
        $address=$_POST['address'];
        $department=$_POST['department'];
        
            $sql = "UPDATE employee_info set name='$name',email='$email',password='$password',salary='$salary',address='$address',department='$department' WHERE id='$id'";  
            $result =mysqli_query($conn,$sql);
            echo "Updated successfully!";
            echo "$sql";
            //header('location:../host/host_user_profile.php');

        
    }
    $sql = "SELECT * FROM employee_info WHERE id='id'";  
    
    $result =mysqli_query($conn,$sql);
    $cur=$result->fetch_assoc();
            

 
?>

    <!-- end edit section php-->





    <?php
    include 'connection.php';
    $query = "SELECT * FROM employee_info";

    $result = mysqli_query($conn,$query);
    //$id = 0;

    while($row = mysqli_fetch_array($result)){
        $id = $row['id'];
        ?>


        <?php
        if(isset($_GET["delete"])){
        
        $delete_user_id = $_GET["delete"];

        $query = " DELETE FROM employee_info WHERE id= {$delete_user_id}";
        $delete_query = mysqli_query($conn, $query);

        if(!$delete_query){
        die("failed". mysqli_error($conn));
    }
        header("Location: show_all.php");
    }

        ?>


        <div class="container-fluid">
            <table class="table table-bordered margin-content text-center">
                <thead>
                <tr>
                    <th>Employee ID</th>
                    <th>Employee Name</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>Salary</th>
                    <th>Phone No.</th>
                    <th>Address</th>
                    <th>Department</th>
                    
<!--                    <th><a href="show_all.php" class="btn btn-danger" onclick="return confirm('Are you sure?');">Delete</a></th>-->
                     <?php
                     echo "<td><a class = 'btn btn-danger' href='show_all.php?delete={$id}'>Delete</a></td>";
                     ?>


                </tr>
                </thead>





                <tbody>
                <tr class="show-all-content">

                    <td>
                        <h4> <?php echo $row['id']; ?> </h4>
                    </td>
                    <td>
                        <h4> <?php echo $row['name']; ?> </h4>
                    </td>
                    <td>
                        <p> <?php echo $row['email'] ?> </p>
                    </td>
                    <td>
                        <p> <?php echo $row['password']; ?> </p>
                    </td>
                    <td>
                        <p> <?php echo $row['salary']; ?> </p>
                    </td>
                    <td>
                        <p> <?php echo $row['phone']; ?> </p>
                    </td>
                    <td>
                        <p> <?php echo $row['address']; ?> </p>
                    </td>
                    <td>
                        <p> <?php echo $row['department']; ?> </p>
                    </td>
                    
                    <td>
                        <!-- Button trigger modal -->
                        <?php
                        echo "<a class='btn btn-primary btn-md' href='edit_employee_profile.php?user_id={$id}'>Edit Profile</a>" ?>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>';
        

    <?php } ?>


    <!-- Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Please change all information! </h4>
                </div>
                <div class="modal-body">

                    <div class="row">
                        <form action="show_all.php" method="POST" class="text-center insert-form">
                            <div class="col-md-4 col-sm-6">
                                <input type="hidden" name="id" id="row_id">
                                <p>Employee Name</p>
                                <input type="text" name="name" value="">
                            </div>
                            <div class="col-md-4 col-sm-6">
                                <p>Email</p>
                                <input type="text" name="email" value="">
                            </div>
                            <div class="col-md-4 col-sm-6">
                                <p>Password</p>
                                <input type="password" name="password" value="">
                            </div>
                            <div class="col-md-4 col-sm-6">
                                <p>Salary</p>
                                <input type="text" name="salary" value="">
                            </div>
                            <div class="col-md-4 col-sm-6">
                                <p>Phone No</p>
                                <input type="text" name="phone" value="">
                            </div>
                            <div class="col-md-4 col-sm-6">
                                <p>Address</p>
                                <input type="text" name="address" value="">
                            </div>
                            <div class="col-md-4 col-sm-6">
                                <p>Department</p>
                                <input type="text" name="department" value="">
                            </div>
                            
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <input class="btn btn-primary" type="submit" name="submit" value="submit"/>
                </div>
                </form>
            </div>
        </div>
    </div>




</div>
<!-- End container -->


<!-- Bootstrap core JavaScript
  =========================================================  -->

<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/script.js"></script>
<script src="js.js"></script>

</body>