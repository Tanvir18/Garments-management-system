<?php
//if(!isset($_SESSION['username'])){
//    echo '<meta http-equiv="refresh" content="0; url=index.php" />';
//}

//include('login_required.php');

include('connection.php');
session_start();
include('session.php');

?>

<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
    <title>Employee Management</title>
    <link rel="stylesheet" type="text/css" href="style.css">

    <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

 
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.2/html5shiv.js"></script> -->
    

</head>
<body>

       <script>
      $(document).ready(function(e){
        $("#Search").keyup(function(){
          $("#here").show();
          var x= $(this).val();
          $.ajax(
          {
              type:'GET',
              url:'fetch.php',
              data:'q='+x,
              success:function(data)
              {
                $("#here").html(data);
              }
          });
        });
      });
    
  </script>
  
  <style type="text/css">
    input
    {
      width: 400px;
      font-size: 24px;
    }
    #here
    {
      width: 400px;
      height: 300px;
      border: .5px solid grey;
      display: none;
    }

    #here a
    {
      display: block;
      width: 98%;
      padding: 1%;
      font-size: 20px;
      border-bottom: .5px solid grey;
    }
  </style>


<div>
<div class="container-fluid">

    <!-- Static navbar -->
    <nav class="navbar navbar-default nav-edit">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php">Employee Report</a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav">
                    <li class="active"><a href="home.php">Home</a></li>
                    <li><a href="insert.php">Insert</a></li>
                    <li><a href="show_all.php">Show all</a></li>
                    <li><a href="notice.php">Notice</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right log-out">
                    <li><a href="log_out.php" class="log-out">LOG OUT</a></li>
                </ul>
            </div><!--/.nav-collapse -->
        </div><!--/.container-fluid -->

        <div class="section">
      <div class="container">
        <div class="row">
          <div class="col-md-offset-3 col-md-7">
            <form role="form">
              <div class="form-group">
                <div class="input-group">
                  <input type="Search" placeholder="Search Employee name" name="Search" id="Search" size="80">
                  <div id="here"></div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

        
    </nav>

     

<div class="container">
    <div class="row text-center">
        <p class="margin-content welcome">Welcome to the Employee management system.</p>
    </div>
    <div class="row">
       <!--  <table class="table home-table">
            <thead>
            <tr>
                <th  class="text-center">Name</th>
                <th  class="text-center">Email</th>
                <th  class="text-center">Mobile</th>
                <th  class="text-center">University</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td  class="text-center">Md. Fayjur Rahman (Sourov)</td>
                <td  class="text-center">sourov.gm@gmail.com</td>
                <td  class="text-center">+8801920387741</td>
                <td  class="text-center">Daffodil International University</td>
            </tr>
            </tbody>
        </table> -->
    </div>
</div>


    




</div>
</div>


<!-- <div class="section">
      <div class="container">
        <div class="row">
          <div class="col-md-offset-3 col-md-7">
            <form role="form">
              <div class="form-group">
                <div class="input-group">
                  <input type="text" placeholder="Search Employee name" name="Search" id="Search" size="80">
                  <div id="here"></div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
 -->

<!-- Bootstrap core JavaScript
  =========================================================  -->

<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/script.js"></script>

</body>