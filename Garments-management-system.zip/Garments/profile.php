<?php
session_start();
include "connection.php";

?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
    <title>Khondoker Garments</title>
    <link rel="stylesheet" type="text/css" href="style.css">

    <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">


    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.2/html5shiv.js"></script> -->


</head>
<body>
<nav class="navbar navbar-default nav-edit">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="ehome.php">Welcome to Khondoker Garments</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
                <li><a href="ehome.php">Home</a></li>
                <li class="active"><a href="profile.php">Profile</a></li>

            </ul>
            <ul class="nav navbar-nav navbar-right log-out">
                <li><a href="log_out.php" class="log-out">LOG OUT</a></li>
            </ul>
        </div><!--/.nav-collapse -->
    </div><!--/.container-fluid -->
</nav>

<div class="container">
    <div id="emp-info" class="">
        <ul id="emp" class="list-unstyled">
            <?php
//            require "loggedEmpInfo.php";
//            getEmpInfo();
            $sql = "select * from `employee_info` WHERE `id`='".$_SESSION['id']."'";
            $res = mysqli_query($conn, $sql);
            while ($row = mysqli_fetch_assoc($res)){
                 $id = $row['id'];
                 $fileToUpload  = $row['photo'];
                 echo "<div id='img_div'>";
                    echo "<img src='image/".$row['photo']."' width='275' height='300' />";
                    echo "</div>";
            ?>
                <li>Name: <?=$row['name'];?></li>
                <li>Email: <?=$row['email'];?></li>
                <li>Salary: <?=$row['salary'];?></li>
                <li>Phone: <?=$row['phone'];?></li>
                <li>Address: <?=$row['address'];?></li>
                <li>Department: <?=$row['department'];?></li>


 <?php           
}
?>
       
       
      
       

                  
                    

        </ul>
    </div>
    <div>
         <?php
                    
                        echo "<a class='btn btn-primary btn-md' href='uploadphoto.php?user_id={$id}'>upload Photo</a>"
                     ?>

    </div>
</div>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/script.js"></script>


</body>
</html>
