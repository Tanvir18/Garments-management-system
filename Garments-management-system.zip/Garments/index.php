
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title>Employee Management</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
</head>

<body>


<script>  
function validateform(){  
var email=document.myform.email.value;  
var password=document.myform.password.value;  
  
if (email==null || email==""){  
  alert("Name can't be blank");  
  return false;  
}else if(password==null || password==""){  
  alert("Password can't be blank");  
  return false; 
  }  
}  
</script>




<?php
    include('connection.php');
  
  
  ?>







  
  <?php
     
     if(isset($_POST['submit'])){
         try{
             
             $email=$_POST['email'];
             $password=$_POST['password'];
             
             
             if(empty($email))
             {
               throw new Exception ("User Name error:user name field cann't be empty <br/>")    ; 
             }
             
             if(empty($password))
             {
               throw new Exception ("Password error:password field cann't be empty <br/>")  ; 
             }
            
             
                 

             $sql = "SELECT * FROM employee_info WHERE email='$email' AND password='$password'";  
             $result =mysqli_query($conn,$sql);

             if($row=$result->fetch_assoc()){

                 session_start();
                 $_SESSION['email']=$email;
                 $_SESSION['id']=$row['id'];
               header('location:ehome.php');
                 return;
             }
                 
                 



                 
                 $sql = "SELECT * FROM admin WHERE username='$email' AND password='$password'";  
                 $result =mysqli_query($conn,$sql);

                 if($row=$result->fetch_assoc()){

                    session_start();
                    
                     $_SESSION['email']=$email;
                     
                     header('location:home.php');
                     //header('cook.php');
                     return;
                     }
                 
                 throw new Exception ("invalid user email or password") ; 
                 
                 
             

             }
         
         catch(Exception $e){
            
            $error_message=$e->getMessage();
         }
        }
     
   ?>
   
   
   <?php
        if(isset($error_message))
        {
            
            echo '<script language="javascript">';
            echo 'alert("'. $error_message.'")';
            echo '</script>';
            
        }

 ?>



<div class="container-fluid margin-top-top">

    <!-- <form class="form-signin" action="index.php" method="post"> -->
    <form name="myform" class="form-signin" method="post" action="index.php" onsubmit="return validateform()" > 
        <h2 class="form-signin-heading">Please sign in</h2>
        <label for="inputEmail" class="sr-only"></label>
        <input type="text" id="inputEmail" name="email" class="form-control" placeholder="User Name" required autofocus>
        <label for="inputPassword" class="sr-only"></label>
        <input type="password" id="inputPassword" name="password" class="form-control" placeholder="Password" required>

        <button class="btn btn-lg btn-primary btn-block" type="submit" name="submit" value="submit">Sign in</button>

        


    </form>

</div> <!-- /container -->
<!-- <form name="myform" method="post" action="abc.jsp" onsubmit="return validateform()" >  
Name: <input type="text" name="name"><br/>  
Password: <input type="password" name="password"><br/>  
<input type="submit" value="register">  
</form> -->  


<!-- Bootstrap core JavaScript
  =========================================================  -->

<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/script.js"></script>

</body>