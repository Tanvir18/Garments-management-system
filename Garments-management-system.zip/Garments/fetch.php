<?php
if(!empty($_GET['q']))
{
	include 'connection.php';
	$q=$_GET['q'];
	$query="select name from employee_info where name like '%$q%'";
	$result=mysqli_query($conn,$query);
	while ($output=mysqli_fetch_assoc($result)) 
	{
		echo "<a>'.$output['name'].'</a>";
	}
}
?>


<!-- <?php
if(!empty($_GET['q']))
{
	include 'config.php';
	$q=$_GET['q'];
	$query="select name,id from host_user where name like '%$q%'";
	$result=mysqli_query($con,$query);
	while ($output=mysqli_fetch_assoc($result)) 
	{
		echo "<a href='cook_profile.php?cook_id=$output[id]' target='_blank'>$output[name]</a>";
	}
}
?> -->