<?php
//if(!isset($_SESSION['username'])){
//    echo '<meta http-equiv="refresh" content="0; url=index.php" />';
//}

//include('login_required.php');

include('connection.php');
session_start();
include('session.php');

?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
    <title>Khondoker Garments</title>
    <link rel="stylesheet" type="text/css" href="style.css">

    <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

 
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.2/html5shiv.js"></script> -->
    

</head>
<body>
<div class="container-fluid">

    <!-- Static navbar -->
    <nav class="navbar navbar-default nav-edit">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="ehome.php">Welcome to Khondoker Garments</a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav">
                    <li class="active"><a href="ehome.php">Home</a></li>
                    <li><a href="profile.php">Profile</a></li>

                </ul>
                <ul class="nav navbar-nav navbar-right log-out">
                    <li><a href="log_out.php" class="log-out">LOG OUT</a></li>
                </ul>
            </div><!--/.nav-collapse -->
        </div><!--/.container-fluid -->
    </nav>

 <?php
                  echo "<h2> Current Notice :</h2>";  
                        echo "</br>";        
                $sql = "SELECT * FROM `notice` order by `id` desc";
                $host =mysqli_query($conn,$sql);
                while($row=mysqli_fetch_assoc($host)){

                    //echo '<div class="col-md-3">';
                   // echo "<div id='img_div'>";
                    //echo "<img src='../a/image/".$hr['photo']."' width='175' height='200' />";
                    //echo "</div>";

                    
//                    echo $row['message'];
                    $json = json_encode($row['message']);
                    echo $json;
                    echo "</br>";
                 
              }
                  ?>
<!--                   <a href="../a/cook_profile.php?cook_id=--><?php //echo $hr['id']; ?><!--"></a>-->

<div>
<!--<table>-->
<!--<tbody>-->
<!--                <tr class="show-all-content">-->
<!---->
<!--                     <td>-->
<!--                        <h4> --><?php //echo $row['message']; ?><!-- </h4>-->
<!--                    </td> -->
<!--                     <td>-->
<!--                        <h4> --><?php //echo $row['name']; ?><!-- </h4>-->
<!--                    </td>-->
<!--                    <td>-->
<!--                        <p> --><?php //echo $row['email'] ?><!-- </p>-->
<!--                    </td>-->
<!--                    <td>-->
<!--                        <p> --><?php //echo $row['password']; ?><!-- </p>-->
<!--                    </td>-->
<!--                    <td>-->
<!--                        <p> --><?php //echo $row['salary']; ?><!-- </p>-->
<!--                    </td>-->
<!--                    <td>-->
<!--                        <p> --><?php //echo $row['phone']; ?><!-- </p>-->
<!--                    </td>-->
<!--                    <td>-->
<!--                        <p> --><?php //echo $row['address']; ?><!-- </p>-->
<!--                    </td>-->
<!--                    <td>-->
<!--                        <p> --><?php //echo $row['department']; ?><!-- </p>-->
<!--                    </td> -->
<!--                    -->
<!--                    -->
<!--                </tr>-->
<!--                </tbody>-->
<!--</table>-->
</div>


<!-- Bootstrap core JavaScript
  =========================================================  -->

<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/script.js"></script>

</body>
</html>