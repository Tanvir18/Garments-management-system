<?php
//if(!isset($_SESSION['username'])){
//    echo '<meta http-equiv="refresh" content="0; url=index.php" />';
//}

//include('login_required.php');
session_start();
include('session.php');
?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/html">
<head lang="en">
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
    <title>Employee Management</title>
    <link rel="stylesheet" type="text/css" href="style.css">

    <!--[if lt IE 9]>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.2/html5shiv.js"></script>
    <![endif]-->

</head>
<body>

<div class="container-fluid">

        <!-- Static navbar -->
        <nav class="navbar navbar-default nav-edit">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="home.php">Employee Info</a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="home.php">Home</a></li>
                        <li><a href="insert.php">Insert</a></li>
                        <li><a href="show_all.php">Show all</a></li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right log-out">
                        <li><a href="log_out.php" class="log-out">LOG OUT</a></li>
                    </ul>
                </div><!--/.nav-collapse -->
            </div><!--/.container-fluid -->
        </nav>


<script>  
function validateform(){  
var name=document.myform.name.value;  
var password=document.myform.password.value; 
var email=document.myform.email.value; 
var x=document.myform.email.value;  
var atposition=x.indexOf("@");  
var dotposition=x.lastIndexOf("."); 
var salary=document.myform.salary.value;
var phone=document.myform.phone.value;

  
if (name==null || name==""){  
  alert("Name can't be blank");  
  return false;  
}
else if (email==null || email==""){  
  alert("Email can't be blank");  
  return false;  
}
else if(atposition<1 || dotposition<atposition+2 || dotposition+2>=x.length){  
  alert("Please enter a valid e-mail address \n atpostion:"+atposition+"\n dotposition:"+dotposition);  
  return false;  
  }
   else if(password==null || password==""){  
  alert("Password can't be blank");  
  return false; 
  }
  else if (salary==null || salary==""){  
  alert("Salary can't be blank");  
  return false;  
}
   else if (isNaN(salary)){  
  document.getElementById("sal").innerHTML="Enter Valid Salary only";  
  return false; 
  } 
  else if (phone==null || phone==""){  
  alert("Phone Number can't be blank");  
  return false;  
}
  else if (isNaN(phone)){  
  document.getElementById("phn").innerHTML="Enter Valid Phone Number only";  
  return false; 
}






}    
  
 

</script>



    

         <?php
    // session_start();
     
    //include('../a/header.php'); 
    include('connection.php');

if(isset($_GET["user_id"])){
  
    $id = $_GET["user_id"];
    
}
    

    if(isset($_POST['submit'])){
         try{
             $name=$_POST['name'];
             $email=$_POST['email'];
             $password=$_POST['password'];
             // $confirm_password=$_POST['confirm_password'];
             $salary=$_POST['salary'];
             $phone=$_POST['phone'];
             $address=$_POST['address'];
             $department=$_POST['department'];
             
             if(empty($name))
             {
               throw new Exception ("Name error:name field cann't be empty ")   ; 
             }
             
             if(empty($email))
             {
               throw new Exception ("Email error:email field cann't be empty")  ; 
             }
             else{
                 $c1=substr_count($email,'@');
                 $c2=substr_count($email,'.');
                 if(($c1!==1)||($c2!==1))
                 {
                   throw new Exception ("Email error: (@/.)cann't be use more than one ")   ; 
                 }
                 else{
                     $len=strlen($email);
                     $p1=strpos($email,'@');
                     if(($p1==0)||($p1==$len-1)){
                        throw new Exception ("Email error: (@)cann't be use first or last position ")   ; 
                     }
                     else{
                        $p2=strpos($email,'.'); 
                        if(($p2==0)||($p2==$len-1)){
                          throw new Exception ("Email error: (@)cann't be use first or last position ") ; 
                           }
                            else{
                                if($p1>$p2)
                                {
                                  throw new Exception ("Email error: (.)cann't be use before(@) ")  ;   
                                }
                                else{
                                    if($p2-$p1==1)
                                    {
                                      throw new Exception ("Email error: need some charecter beetween(.)-(@)")  ;   
                                    }
                                }
                            }
                        }
                     }
                 }
                

                 
            /* 
             if(empty($password))
             {
               throw new Exception ("Password error:password field cann't be empty ")   ; 
             }
             if(empty($confirm_password))
             {
               throw new Exception ("Password error:confirm password field cann't be empty ")   ; 
             }
             else{
                 if($password!==$confirm_password){
                    throw new Exception ("Password error:password does not match ");     
                 }
             }
             if(empty($contact))
             {
               throw new Exception ("conatct error:conatct field cann't be empty ") ; 
             }
             if(empty($address))
             {
               throw new Exception ("Address error:Address field cann't be empty")  ; 
             }*/
              $sql = "UPDATE employee_info set name='$name',email='$email',password='$password',salary='$salary',address='$address',department='$department' WHERE id='".$id."'";  
            $result =mysqli_query($conn,$sql);
            echo "Updated successfully!";
             mysqli_query($conn,$sql);
             //header('location:signin.php');

             //echo "$sql";
             echo "insert successful";
            
             
 
         }
         catch(Exception $e){
            
            $error_message=$e->getMessage();
         }
     }
   ?>
   
   
    <?php
        if(isset($error_message))
        {
            
            echo '<script language="javascript">';
            echo 'alert("'. $error_message.'")';
            echo '</script>';
            
        }

  
            // $sql = "UPDATE employee_info set name='$name',email='$email',password='$password',salary='$salary',address='$address',department='$department' WHERE id='".$id."'";  
            // $result =mysqli_query($conn,$sql);
            // echo "Updated successfully!";
            //echo "$sql";
            //header('location:../host/host_user_profile.php');

        
    
    $sql = "SELECT * FROM employee_info WHERE id='id'";  
    
    $result =mysqli_query($conn,$sql);
    $cur=$result->fetch_assoc();
            

 
?>
   
   
    <?php
        if(isset($error_message))
        {
            
            echo '<script language="javascript">';
            echo 'alert("'. $error_message.'")';
            echo '</script>';
            
        }

 ?>
            <!-- <?php
            if(mysql_query($sql)){
                echo '<h1 class="notice text-center">Insert successfully</h1>';
            }
            else{
                echo '<h1 class="notice text-center">Not Insert</h1>';
            }
        
        ?> -->

    <div class="row">
        <form name="myform" action="" method="post" class="text-center insert-form" onsubmit="return validateform()" >
            <div class="col-md-4 col-sm-6">
                <input type="hidden" name="id">
                <p>Employee Name</p>
                <input type="text" name="name" value="">
            </div>
            <div class="col-md-4 col-sm-6">
                <p>Email</p>
                <input type="text" name="email" value="">
            </div>
            <div class="col-md-4 col-sm-6">
                <p>Password</p>
                <input type="password" name="password" value="">
            </div>
            <div class="col-md-4 col-sm-6">
                <p>Salary</p>
                <input type="text" name="salary" value=""><span id="sal"></span><br/> 
            </div>
            <div class="col-md-4 col-sm-6">
                <p>Phone No</p>
                <input type="text" name="phone" value=""><span id="phn"></span><br/> 
            </div>
            <div class="col-md-4 col-sm-6">
                <p>Address</p>
                <input type="text" name="address" value="">
            </div>
            <div class="col-md-4 col-sm-6">
                <p>Department</p>
                <input type="text" name="department" value="">
            </div>
            
            <div class="col-md-12">
                <div class="submite-button">
                    <button class="btn btn-primary btn-block" type="submit" name="submit" value="save">Submit</button>
                </div>
            </div>
        </form>
    </div>

  
</div>





<!-- Bootstrap core JavaScript
  =========================================================  -->

<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/script.js"></script>

</body>